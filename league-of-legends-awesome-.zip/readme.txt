﻿=== league of legends awesome mouse pointers Cursor Set ===

By: SeeGreatness (http://www.rw-designer.com/user/52170) chris@willner.ca

Download: http://www.rw-designer.com/cursor-set/league-of-legends-awesome-

Author's description:

use it on your pc (works in league...obviously)

==========

License: Creative Commons - Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Noncommercial - You may not use this work for commercial purposes.